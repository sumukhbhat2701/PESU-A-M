struct test 
{ 
  unsigned int x[10]: 5; 
}; 
  
int main(void) 
{ 
  
} 