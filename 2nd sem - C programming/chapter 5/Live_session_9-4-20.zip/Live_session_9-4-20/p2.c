//Command line argument: check give number is even or odd
#include<stdio.h>
#include<stdlib.h>
int main(int argc,char* argv[])
{
	printf("%s\n",argv[0]);
	if(argc>1)
	{
		if(atoi(argv[1])%2==0)  //as argv is string convert to integer to check even/odd
			printf("Even\n");
		else
			printf("Odd");
	}
	else
	{
		printf("less argc count\n");
	}
	
}
//try out few test cases:-
//filename 10
//filename 12
//filename  // this is we end up getting wrong result because argument should be two i.e, filename and any value

