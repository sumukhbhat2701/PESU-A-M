//volatile qualifier example:
#include<stdio.h>
int main()
{
	volatile int a=10; //volatile keyword used to indicate to compiler that, not to optimise this variable in the expression
	int b=20;
	int res=a+b+90;
	printf("adding");
	a=111;
	int d=a+b+res+99;
	return 0;
}