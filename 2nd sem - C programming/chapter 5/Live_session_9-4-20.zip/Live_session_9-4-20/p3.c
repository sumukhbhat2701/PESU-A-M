/*
variable
	name
	location
	type	
	value
	storage classes:
		auto
		static
		register
		global //
	specifiers:
		signed
		typedef
		short 
		long
	qualifiers
		const
		volatile
		
	lifetime
	scope
*/
//auto and register stoarge class example:
#include<stdio.h>
register int r; //not allowed
int main()
{
	int a=10; /without keyword auto
	//auto int a; //with keyword auto
	/*int b;//junk
	int *p;	//untialized pointer
	printf("a=%d and b=%d\n",a,b);  //op: a=10 b=junk
	{
		int a=99;int c=88;
		printf("in blk a=%d and b=%d\n",a,b); //op: a=99 b=junk and c=88
		p=&c;
		printf("*p=%d\n",*p); //op: *p=88 
	}*/
	printf("*p=%d\n",*p); //op: undefined & this way of defererencing pointer leads to dangling pointer 
//example for register :
	register int i; int sum=0;
	for(i=0;i<10;++i)
	{
		sum+=i;
			
	}
	//printf("%p\n",&i); //cannot access address of register variable
	printf("sum=%d\n",sum);
	

	
}













