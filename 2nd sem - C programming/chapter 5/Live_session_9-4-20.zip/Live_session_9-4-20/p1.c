//Command line arguments
#include<stdio.h>
int main(int argc,char* argv[])  //argc : argument count(int) & argv : argument vector(pointer to array of char's)
{
	printf("argc=%d\n",argc); //to dispaly argument count
	printf("argv[0]=%s\n",argv[0]); 
	//printf("argv[1]=%s\n",argv[1]);// we get (null) as output if try to access beyond
	for(int i=1;i<argc;++i) //to display all arguments
	{
		printf("%s ",argv[i]);
		
	}
}
//diff ways main() is called:
//main(void)
//main()
//main(int argc,char* argv[])
//main(int *argc,char* argv[],char **envp)