#include<stdio.h>
//pragma
//#pragma pack(n) //n=1 2 or 4
#pragma pack(1)
struct sample
{
	int a; //4 bytes
	char b; //1 byte + 3 padding
	int x;//4 byte
};
int main()
{
	printf("%lu\n",sizeof(struct sample));
	
	return 0;
}
