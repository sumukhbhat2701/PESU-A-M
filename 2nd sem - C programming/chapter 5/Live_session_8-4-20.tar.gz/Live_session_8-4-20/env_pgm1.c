#include<stdio.h>
#include<stdlib.h>
// environment:
//	OS provides an environment in which the programs work.
//	Examples:
//	path, pwd etc.,
//	$ env or printenv //command to list all envirnoment variables available in unbuntu
//	Each entry is a key value pair - both are strings
//	We can access or modify(create) these using getenv and setenv functions.
//	This feature is OS dependent
//	Consider an example:-
//	PATH ->The value is a sequence of directory names separated by : in unix and ; in microsoft windows

// Also note that this change does not affect the program or the shell running this.
int main()
{
	printf("%s\n",getenv("PATH"));
	printf("%s\n",getenv("HOME"));
	printf("%s\n",getenv("PWD"));
	putenv("LOGNAME=Unix");
	printf("%s\n",getenv("LOGNAME"));
	setenv("LOGNAME","Unbuntu",1);
	printf("%s\n",getenv("LOGNAME"));
	putenv("UNAME=Savitri");
	printf("%s\n",getenv("UNAME"));
	setenv("UNAME","ss",1);
	printf("%s\n",getenv("UNAME"));
	unsetenv("UNAME");
	printf("%s\n",getenv("UNAME"));
	return 0;
}



