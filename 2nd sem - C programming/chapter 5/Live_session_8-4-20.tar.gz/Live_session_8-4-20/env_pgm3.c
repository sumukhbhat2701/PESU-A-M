//Pgm to display all the environment variable
#include<stdio.h>
#include<stdio.h>
extern char **environ;
int main(int argc,char *argv[],char *envp[]) //**envp
{
	for(int i=0;environ[i]!=NULL;++i)
	{
		printf("%s\n",environ[i]);
	}
	return 0;
}

