#include<stdio.h>
//std macros
int main()
{
	#ifdef __MINGW32__
		printf("Windows OS\n");
		char ch;
		printf("Enter a character\n");
		scanf("%c",&ch);
		char ch1;
		printf("Enter another character\n");
		fflush(stdin);
		scanf("%c",&ch1);
	#elif __unix__
		#include<stdio_ext.h>
		printf("Unix OS\n");
		char ch;
		printf("Enter a character\n");
		scanf("%c",&ch);
		char ch1;
		printf("Enter another character\n");
		__fpurge(stdin);
		scanf("%c",&ch1);
	#elif __Apple
		printf("Mac OS\n");
		char ch;
		printf("Enter a character\n");
		scanf("%c",&ch);
		char ch1;
		printf("Enter another character\n");
		scanf("%c",&ch1);
	#else
		printf("Other OS\n");
	#endif
	return 0;
}
