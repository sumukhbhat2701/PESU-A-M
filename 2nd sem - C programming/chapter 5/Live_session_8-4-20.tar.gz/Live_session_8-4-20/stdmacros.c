#include<stdio.h>
//std macros
int main()
{
	printf("%s\n",__DATE__);
	printf("%s\n",__TIME__);
	printf("%s\n",__FILE__);
	if(__LINE__==8)
	{
		printf("Am in line 8!\n");
	}
	printf("%lu\n",__STDC_VERSION__);
	printf("%d\n",__STDC__);
	return 0;
}
