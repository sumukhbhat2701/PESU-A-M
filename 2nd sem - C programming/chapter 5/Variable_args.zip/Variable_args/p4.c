//pgm to find minimum element in the list of elements given using var args
#include<stdio.h>
#include<stdarg.h>
double min(int args,...)
{
	va_list ap; double res;
	va_start(ap,args);
	double minele=va_arg(ap,double);
	for(int i=1;i<args;++i)
	{
		if((res=va_arg(ap,double))<minele)
			minele=res;
	}
	va_end(ap);
	return minele;
	
}
int main()
{
	printf("%lf\n",min(4,10.0,34.56,0.0,23.78));
	printf("%lf\n",min(7,10.0,34.56,0.0,23.78,10.0,0.0,-12.0));
	return 0;
}