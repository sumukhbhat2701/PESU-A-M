#include<stdio.h>
//int add(int,int);
int main()
{
	//few variations with printf to understand working of it
	int a=10;
	printf("Live stream\n");
	printf("Live stream is at %d\n",11);
	printf("%d\n",10);
	printf("%d\n",a);
	printf("%d %f\n",10,23.56);
	printf("%d\n",10,20);//??
	printf("%d %d %d\n",10,20);//??
	printf("%d\n",10.56); //??
	

	/*printf("%d",add(1,2));
	printf("%d",add(1,2,3,4)); //?? this will be compile time error as argument and parameter not matching
	*/

	return 0;
}


/*int add(int x,int y)
{
	return x+y;
}*/