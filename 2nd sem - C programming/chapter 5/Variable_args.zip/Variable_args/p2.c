//add function using variable num of arg's
#include<stdio.h>
#include<stdarg.h>
int add(int,...);
int main()
{
	printf("sum=%d\n",add(2,1,2));
	printf("%d\n",add(4,10,20,30,40));

//few below statments not allowed:
// printf("sum=%d\n",add(0,1,2));
// printf("sum=%d\n",add(0,1,2));
// printf("sum=%d\n",add(0,1,2));
}
int add(int args,...)
{
	va_list ap; int sum=0; int res;
	va_start(ap,args);
	printf("args=%d\n",args);
	va_arg(ap,int);
	for(int i=1;i<args;++i){
		//sum+=va_arg(ap,int);
		res=va_arg(ap,int);
		printf("res=%d ap=%p\n",res,ap);
		sum+=res;
	}
	va_end(ap);
	return sum;
	
	
}