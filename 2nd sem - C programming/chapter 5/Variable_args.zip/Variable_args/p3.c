//Program to display
#include<stdio.h>
#include<stdarg.h>
void dispstr(int n,...)
{
	va_list a; va_list b;
	va_start(a,n);
	va_copy(b,a);
	while(n--)
	{
		printf("%s\n",va_arg(a,char *));
	}
	va_end(a);
	printf("%s\n",va_arg(b,char*));
	va_end(b);
}
int main()
{
	dispstr(3,"c","c++","python");
	dispstr(4,"kiwi","orange","apple","bannana");
}