
void read_matrix(int rowsize; int columnsize; int x[rowsize][columnsize], 
		int rowsize, int columnsize, int m, int n);  
void disp_matrix(int rowsize; int columnsize; int x[rowsize][columnsize], 
		int rowsize, int columnsize, int m, int n);  



