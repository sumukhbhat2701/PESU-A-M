int sqr(int);
int cube(int);
