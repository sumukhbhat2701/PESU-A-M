int is_palindrome(int n);
