#include<stdio.h>
struct student			 
{						 
	int rnum;			 
	char name[20];		
	int marks;
};					
typedef struct student student_t;

int main()
{
	student_t s1;
	// ...
	
}
