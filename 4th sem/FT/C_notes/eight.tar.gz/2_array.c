#include <stdio.h>
#include "2_util.h"

int main()
{
	int a[5];
	int n  = 5;
	read_array(a, n);
	disp_array(a, n);
}
