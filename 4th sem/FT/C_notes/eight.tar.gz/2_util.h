void read_array(int x[], int n);
void disp_array(int *x, int n);
