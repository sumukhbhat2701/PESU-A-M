#ifndef SEARCH_H
#define SEARCH_H
int bsearch(int a[], int l, int r, int x);
#endif
