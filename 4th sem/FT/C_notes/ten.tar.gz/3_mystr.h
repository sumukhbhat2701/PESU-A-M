// pos in the text if pattern found in the text otherwise -1
int mymatch(char text[], int n, char pattern[], int m);
