// find the pos of ch in src;
// return the pos if found
//        -1 if not found
int find_left(const char *src, char ch);
