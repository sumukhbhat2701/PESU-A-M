void disp_array(int x[], int n);

