int mystrlen(char*);
// int mystrlen(char []); // no diff
void mystrcpy(char *dst, char *src);
int	mystrcmp(char *s1, char *s2);
